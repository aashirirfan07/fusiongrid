import {
  BarChart3, TrendingUp, Clock, CheckCircle2, ArrowRight,
} from 'lucide-react';
import {
  AreaChart, Area, BarChart, Bar, LineChart, Line, PieChart, Pie, Cell,
  XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Legend,
} from 'recharts';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import {
  adminChartApiRequests, adminChartSlaCompliance,
  adminChartDepartmentWorkload, adminChartProcessingTime,
  adminChartDataQuality, adminChartSuccessFailure,
} from '@/data/adminData';

interface AnalyticsProps {
  navigate: (to: string) => void;
}

export function Analytics({ navigate }: AnalyticsProps) {
  return (
    <div className="mx-auto max-w-7xl px-4 py-6 sm:px-6 lg:px-8">
      <div className="mb-6 animate-fade-in-up">
        <h1 className="font-display text-2xl font-bold tracking-tight">Analytics</h1>
        <p className="mt-1 text-sm text-muted-foreground">
          System-wide analytics across API traffic, department workload, processing times, and data quality.
        </p>
      </div>

      {/* API Traffic */}
      <Card className="mb-6 border-border/60 animate-fade-in-up">
        <CardHeader>
          <CardTitle className="flex items-center gap-2 text-base">
            <TrendingUp className="h-4 w-4 text-primary" />
            API Traffic (24h)
          </CardTitle>
          <CardDescription>Hourly request volume and failure trends</CardDescription>
        </CardHeader>
        <CardContent>
          <ResponsiveContainer width="100%" height={300}>
            <AreaChart data={adminChartApiRequests}>
              <defs>
                <linearGradient id="colorReq" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor="hsl(210 80% 50%)" stopOpacity={0.3} />
                  <stop offset="95%" stopColor="hsl(210 80% 50%)" stopOpacity={0} />
                </linearGradient>
                <linearGradient id="colorFail" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor="hsl(0 72% 51%)" stopOpacity={0.3} />
                  <stop offset="95%" stopColor="hsl(0 72% 51%)" stopOpacity={0} />
                </linearGradient>
              </defs>
              <CartesianGrid strokeDasharray="3 3" stroke="hsl(210 40% 90%)" />
              <XAxis dataKey="hour" tick={{ fontSize: 11 }} stroke="hsl(210 40% 50%)" />
              <YAxis tick={{ fontSize: 11 }} stroke="hsl(210 40% 50%)" />
              <Tooltip contentStyle={{ borderRadius: '8px', fontSize: '12px' }} />
              <Legend wrapperStyle={{ fontSize: '12px' }} />
              <Area type="monotone" dataKey="requests" stroke="hsl(210 80% 50%)" fill="url(#colorReq)" name="Requests" />
              <Area type="monotone" dataKey="failures" stroke="hsl(0 72% 51%)" fill="url(#colorFail)" name="Failures" />
            </AreaChart>
          </ResponsiveContainer>
        </CardContent>
      </Card>

      {/* Department Workload + Success/Failure */}
      <div className="mb-6 grid gap-4 lg:grid-cols-2 animate-fade-in-up">
        <Card className="border-border/60">
          <CardHeader>
            <CardTitle className="flex items-center gap-2 text-base">
              <BarChart3 className="h-4 w-4 text-primary" />
              Department Workload
            </CardTitle>
            <CardDescription>API requests by department this week</CardDescription>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={300}>
              <BarChart data={adminChartDepartmentWorkload} layout="vertical">
                <CartesianGrid strokeDasharray="3 3" stroke="hsl(210 40% 90%)" horizontal={false} />
                <XAxis type="number" tick={{ fontSize: 11 }} stroke="hsl(210 40% 50%)" />
                <YAxis type="category" dataKey="department" tick={{ fontSize: 11 }} stroke="hsl(210 40% 50%)" width={80} />
                <Tooltip contentStyle={{ borderRadius: '8px', fontSize: '12px' }} />
                <Bar dataKey="requests" radius={[0, 4, 4, 0]}>
                  {adminChartDepartmentWorkload.map((entry, i) => (
                    <Cell key={i} fill={entry.fill} />
                  ))}
                </Bar>
              </BarChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>

        <Card className="border-border/60">
          <CardHeader>
            <CardTitle className="flex items-center gap-2 text-base">
              <CheckCircle2 className="h-4 w-4 text-primary" />
              API Call Outcomes
            </CardTitle>
            <CardDescription>Success vs failure vs timeout distribution</CardDescription>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={300}>
              <PieChart>
                <Pie data={adminChartSuccessFailure} dataKey="value" nameKey="name" cx="50%" cy="50%" outerRadius={100} innerRadius={60} label={({ name, percent }) => `${name} ${(percent! * 100).toFixed(1)}%`}>
                  {adminChartSuccessFailure.map((entry, i) => (
                    <Cell key={i} fill={entry.fill} />
                  ))}
                </Pie>
                <Tooltip contentStyle={{ borderRadius: '8px', fontSize: '12px' }} />
              </PieChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>
      </div>

      {/* Processing Time + SLA */}
      <div className="mb-6 grid gap-4 lg:grid-cols-2 animate-fade-in-up">
        <Card className="border-border/60">
          <CardHeader>
            <CardTitle className="flex items-center gap-2 text-base">
              <Clock className="h-4 w-4 text-primary" />
              Processing Time by Department
            </CardTitle>
            <CardDescription>Average latency (ms) over 7 days</CardDescription>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={300}>
              <LineChart data={adminChartProcessingTime}>
                <CartesianGrid strokeDasharray="3 3" stroke="hsl(210 40% 90%)" />
                <XAxis dataKey="day" tick={{ fontSize: 11 }} stroke="hsl(210 40% 50%)" />
                <YAxis tick={{ fontSize: 11 }} stroke="hsl(210 40% 50%)" unit="ms" />
                <Tooltip contentStyle={{ borderRadius: '8px', fontSize: '12px' }} />
                <Legend wrapperStyle={{ fontSize: '12px' }} />
                <Line type="monotone" dataKey="identity" stroke="hsl(262 60% 55%)" name="Identity" strokeWidth={2} dot={{ r: 3 }} />
                <Line type="monotone" dataKey="revenue" stroke="hsl(210 80% 50%)" name="Revenue" strokeWidth={2} dot={{ r: 3 }} />
                <Line type="monotone" dataKey="education" stroke="hsl(142 64% 42%)" name="Education" strokeWidth={2} dot={{ r: 3 }} />
                <Line type="monotone" dataKey="health" stroke="hsl(0 72% 51%)" name="Health" strokeWidth={2} dot={{ r: 3 }} />
              </LineChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>

        <Card className="border-border/60">
          <CardHeader>
            <CardTitle className="flex items-center gap-2 text-base">
              <TrendingUp className="h-4 w-4 text-primary" />
              SLA Compliance Trend
            </CardTitle>
            <CardDescription>Weekly compliance percentage</CardDescription>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={300}>
              <LineChart data={adminChartSlaCompliance}>
                <CartesianGrid strokeDasharray="3 3" stroke="hsl(210 40% 90%)" />
                <XAxis dataKey="week" tick={{ fontSize: 11 }} stroke="hsl(210 40% 50%)" />
                <YAxis tick={{ fontSize: 11 }} stroke="hsl(210 40% 50%)" domain={[90, 100]} unit="%" />
                <Tooltip contentStyle={{ borderRadius: '8px', fontSize: '12px' }} />
                <Line type="monotone" dataKey="compliance" stroke="hsl(142 71% 45%)" strokeWidth={3} dot={{ r: 5 }} name="Compliance %" />
              </LineChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>
      </div>

      {/* Data Quality */}
      <Card className="mb-6 border-border/60 animate-fade-in-up">
        <CardHeader>
          <CardTitle className="text-base">Data Quality Issues by Type</CardTitle>
          <CardDescription>Distribution of active and resolved data quality issues</CardDescription>
        </CardHeader>
        <CardContent>
          <ResponsiveContainer width="100%" height={300}>
            <BarChart data={adminChartDataQuality}>
              <CartesianGrid strokeDasharray="3 3" stroke="hsl(210 40% 90%)" vertical={false} />
              <XAxis dataKey="type" tick={{ fontSize: 10 }} stroke="hsl(210 40% 50%)" angle={-15} textAnchor="end" height={50} />
              <YAxis tick={{ fontSize: 11 }} stroke="hsl(210 40% 50%)" />
              <Tooltip contentStyle={{ borderRadius: '8px', fontSize: '12px' }} />
              <Bar dataKey="count" radius={[4, 4, 0, 0]}>
                {adminChartDataQuality.map((entry, i) => (
                  <Cell key={i} fill={entry.fill} />
                ))}
              </Bar>
            </BarChart>
          </ResponsiveContainer>
        </CardContent>
      </Card>

      <div className="flex items-center justify-end">
        <Button variant="ghost" size="sm" onClick={() => navigate('/admin/dashboard')} className="gap-1">
          <ArrowRight className="h-3.5 w-3.5 rotate-180" />
          Back to Dashboard
        </Button>
      </div>
    </div>
  );
}
