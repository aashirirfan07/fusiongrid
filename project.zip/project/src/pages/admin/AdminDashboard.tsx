import {
  BarChart, Bar, LineChart, Line, AreaChart, Area, PieChart, Pie, Cell,
  XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Legend,
} from 'recharts';
import {
  Network, Activity, Zap, CheckCircle2, Gauge, AlertTriangle,
  ArrowRight, TrendingUp, Clock, Database, ScrollText,
} from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import {
  adminMetrics, adminChartApiRequests, adminChartSlaCompliance,
  adminChartDepartmentWorkload, adminChartProcessingTime,
  adminChartDataQuality, adminChartSuccessFailure,
} from '@/data/adminData';
import { useApp } from '@/context/AppContext';
import { cn } from '@/lib/utils';

interface AdminDashboardProps {
  navigate: (to: string) => void;
}

export function AdminDashboard({ navigate }: AdminDashboardProps) {
  const metrics = [
    { label: 'Connected Departments', value: adminMetrics.connectedDepartments, icon: Network, color: 'text-blue-600', bg: 'bg-blue-50' },
    { label: 'Active APIs', value: adminMetrics.activeApis, icon: Activity, color: 'text-green-600', bg: 'bg-green-50' },
    { label: 'Requests Today', value: adminMetrics.requestsToday, icon: Zap, color: 'text-amber-600', bg: 'bg-amber-50' },
    { label: 'Avg Latency', value: `${adminMetrics.avgLatency}ms`, icon: Clock, color: 'text-purple-600', bg: 'bg-purple-50' },
    { label: 'API Success Rate', value: `${adminMetrics.apiSuccessRate}%`, icon: CheckCircle2, color: 'text-emerald-600', bg: 'bg-emerald-50' },
    { label: 'SLA Compliance', value: `${adminMetrics.slaCompliance}%`, icon: Gauge, color: 'text-orange-600', bg: 'bg-orange-50' },
  ];

  return (
    <div className="mx-auto max-w-7xl px-4 py-6 sm:px-6 lg:px-8">
      <div className="mb-6 animate-fade-in-up">
        <div className="flex items-center gap-2">
          <h1 className="font-display text-2xl font-bold tracking-tight">FusionGrid Control Center</h1>
          <Badge variant="outline" className="border-amber-300 bg-amber-50 text-amber-700">
            <AlertTriangle className="mr-1 h-3 w-3" />
            Fictional Prototype
          </Badge>
        </div>
        <p className="mt-1 text-sm text-muted-foreground">
          System-wide interoperability monitoring, API gateway health, and data quality oversight.
        </p>
      </div>

      {/* Metrics grid */}
      <div className="mb-6 grid grid-cols-2 gap-4 sm:grid-cols-3 lg:grid-cols-6 animate-fade-in-up">
        {metrics.map((m) => {
          const Icon = m.icon;
          return (
            <Card key={m.label} className="border-border/60">
              <CardContent className="p-4">
                <div className={cn('mb-2 flex h-9 w-9 items-center justify-center rounded-lg', m.bg)}>
                  <Icon className={cn('h-4.5 w-4.5', m.color)} />
                </div>
                <p className="text-2xl font-bold tracking-tight">{m.value}</p>
                <p className="mt-0.5 text-xs text-muted-foreground">{m.label}</p>
              </CardContent>
            </Card>
          );
        })}
      </div>

      {/* Charts row 1: API Requests + Success/Failure */}
      <div className="mb-6 grid gap-4 lg:grid-cols-3 animate-fade-in-up">
        <Card className="border-border/60 lg:col-span-2">
          <CardHeader>
            <CardTitle className="flex items-center gap-2 text-base">
              <TrendingUp className="h-4 w-4 text-primary" />
              API Requests Over Time (24h)
            </CardTitle>
            <CardDescription>Hourly request volume and failure count across all connectors</CardDescription>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={280}>
              <AreaChart data={adminChartApiRequests}>
                <defs>
                  <linearGradient id="colorRequests" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="hsl(210 80% 50%)" stopOpacity={0.3} />
                    <stop offset="95%" stopColor="hsl(210 80% 50%)" stopOpacity={0} />
                  </linearGradient>
                  <linearGradient id="colorFailures" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="hsl(0 72% 51%)" stopOpacity={0.3} />
                    <stop offset="95%" stopColor="hsl(0 72% 51%)" stopOpacity={0} />
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" stroke="hsl(210 40% 90%)" />
                <XAxis dataKey="hour" tick={{ fontSize: 11 }} stroke="hsl(210 40% 50%)" />
                <YAxis tick={{ fontSize: 11 }} stroke="hsl(210 40% 50%)" />
                <Tooltip contentStyle={{ borderRadius: '8px', border: '1px solid hsl(210 40% 85%)', fontSize: '12px' }} />
                <Legend wrapperStyle={{ fontSize: '12px' }} />
                <Area type="monotone" dataKey="requests" stroke="hsl(210 80% 50%)" fillOpacity={1} fill="url(#colorRequests)" name="Requests" />
                <Area type="monotone" dataKey="failures" stroke="hsl(0 72% 51%)" fillOpacity={1} fill="url(#colorFailures)" name="Failures" />
              </AreaChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>

        <Card className="border-border/60">
          <CardHeader>
            <CardTitle className="text-base">Success / Failure Distribution</CardTitle>
            <CardDescription>Today's API call outcomes</CardDescription>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={280}>
              <PieChart>
                <Pie data={adminChartSuccessFailure} dataKey="value" nameKey="name" cx="50%" cy="50%" outerRadius={90} innerRadius={50} label={({ name, percent }) => `${name} ${(percent! * 100).toFixed(1)}%`}>
                  {adminChartSuccessFailure.map((entry, i) => (
                    <Cell key={i} fill={entry.fill} />
                  ))}
                </Pie>
                <Tooltip contentStyle={{ borderRadius: '8px', fontSize: '12px' }} />
              </PieChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>
      </div>

      {/* Charts row 2: Department Workload + Processing Time */}
      <div className="mb-6 grid gap-4 lg:grid-cols-2 animate-fade-in-up">
        <Card className="border-border/60">
          <CardHeader>
            <CardTitle className="text-base">Department Workload</CardTitle>
            <CardDescription>API requests by department (this week)</CardDescription>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={280}>
              <BarChart data={adminChartDepartmentWorkload} layout="vertical">
                <CartesianGrid strokeDasharray="3 3" stroke="hsl(210 40% 90%)" horizontal={false} />
                <XAxis type="number" tick={{ fontSize: 11 }} stroke="hsl(210 40% 50%)" />
                <YAxis type="category" dataKey="department" tick={{ fontSize: 11 }} stroke="hsl(210 40% 50%)" width={80} />
                <Tooltip contentStyle={{ borderRadius: '8px', fontSize: '12px' }} />
                <Bar dataKey="requests" radius={[0, 4, 4, 0]}>
                  {adminChartDepartmentWorkload.map((entry, i) => (
                    <Cell key={i} fill={entry.fill} />
                  ))}
                </Bar>
              </BarChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>

        <Card className="border-border/60">
          <CardHeader>
            <CardTitle className="text-base">Processing Time by Department</CardTitle>
            <CardDescription>Average latency in milliseconds (7 days)</CardDescription>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={280}>
              <LineChart data={adminChartProcessingTime}>
                <CartesianGrid strokeDasharray="3 3" stroke="hsl(210 40% 90%)" />
                <XAxis dataKey="day" tick={{ fontSize: 11 }} stroke="hsl(210 40% 50%)" />
                <YAxis tick={{ fontSize: 11 }} stroke="hsl(210 40% 50%)" unit="ms" />
                <Tooltip contentStyle={{ borderRadius: '8px', fontSize: '12px' }} />
                <Legend wrapperStyle={{ fontSize: '12px' }} />
                <Line type="monotone" dataKey="identity" stroke="hsl(262 60% 55%)" name="Identity" strokeWidth={2} dot={{ r: 3 }} />
                <Line type="monotone" dataKey="revenue" stroke="hsl(210 80% 50%)" name="Revenue" strokeWidth={2} dot={{ r: 3 }} />
                <Line type="monotone" dataKey="education" stroke="hsl(142 64% 42%)" name="Education" strokeWidth={2} dot={{ r: 3 }} />
                <Line type="monotone" dataKey="health" stroke="hsl(0 72% 51%)" name="Health" strokeWidth={2} dot={{ r: 3 }} />
              </LineChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>
      </div>

      {/* Charts row 3: SLA Compliance + Data Quality Issues */}
      <div className="mb-6 grid gap-4 lg:grid-cols-2 animate-fade-in-up">
        <Card className="border-border/60">
          <CardHeader>
            <CardTitle className="text-base">SLA Compliance Trend</CardTitle>
            <CardDescription>Weekly SLA compliance percentage</CardDescription>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={280}>
              <LineChart data={adminChartSlaCompliance}>
                <CartesianGrid strokeDasharray="3 3" stroke="hsl(210 40% 90%)" />
                <XAxis dataKey="week" tick={{ fontSize: 11 }} stroke="hsl(210 40% 50%)" />
                <YAxis tick={{ fontSize: 11 }} stroke="hsl(210 40% 50%)" domain={[90, 100]} unit="%" />
                <Tooltip contentStyle={{ borderRadius: '8px', fontSize: '12px' }} />
                <Line type="monotone" dataKey="compliance" stroke="hsl(142 71% 45%)" strokeWidth={3} dot={{ r: 5 }} name="Compliance %" />
              </LineChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>

        <Card className="border-border/60">
          <CardHeader>
            <CardTitle className="text-base">Data Quality Issues</CardTitle>
            <CardDescription>Issues by type (active + resolved)</CardDescription>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={280}>
              <BarChart data={adminChartDataQuality}>
                <CartesianGrid strokeDasharray="3 3" stroke="hsl(210 40% 90%)" vertical={false} />
                <XAxis dataKey="type" tick={{ fontSize: 10 }} stroke="hsl(210 40% 50%)" angle={-15} textAnchor="end" height={50} />
                <YAxis tick={{ fontSize: 11 }} stroke="hsl(210 40% 50%)" />
                <Tooltip contentStyle={{ borderRadius: '8px', fontSize: '12px' }} />
                <Bar dataKey="count" radius={[4, 4, 0, 0]}>
                  {adminChartDataQuality.map((entry, i) => (
                    <Cell key={i} fill={entry.fill} />
                  ))}
                </Bar>
              </BarChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>
      </div>

      {/* Quick links */}
      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4 animate-fade-in-up">
        {[
          { label: 'Department Integrations', path: '/admin/integrations', icon: Network },
          { label: 'API Gateway Monitor', path: '/admin/api-monitor', icon: Activity },
          { label: 'Data Quality', path: '/admin/data-quality', icon: Database },
          { label: 'Audit Logs', path: '/admin/audit', icon: ScrollText },
        ].map((link) => {
          const Icon = link.icon;
          return (
            <button
              key={link.path}
              onClick={() => navigate(link.path)}
              className="group flex items-center gap-3 rounded-lg border border-border/60 bg-card p-4 text-left transition-all hover:border-primary/30 hover:shadow-md"
            >
              <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-primary/10 text-primary">
                <Icon className="h-5 w-5" />
              </div>
              <span className="flex-1 text-sm font-semibold">{link.label}</span>
              <ArrowRight className="h-4 w-4 text-muted-foreground transition-transform group-hover:translate-x-1" />
            </button>
          );
        })}
      </div>
    </div>
  );
}
