import {
  HeartPulse, CheckCircle2, AlertTriangle, XCircle, Wrench,
  Activity, Clock, Zap, ArrowRight,
} from 'lucide-react';
import {
  BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Cell,
} from 'recharts';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { systemHealthItems } from '@/data/adminData';
import { useApp } from '@/context/AppContext';
import type { SystemHealthStatus } from '@/types';
import { cn } from '@/lib/utils';

interface SystemHealthProps {
  navigate: (to: string) => void;
}

const statusConfig: Record<SystemHealthStatus, { label: string; icon: typeof CheckCircle2; color: string; bg: string; border: string; dot: string }> = {
  operational: { label: 'Operational', icon: CheckCircle2, color: 'text-emerald-600', bg: 'bg-emerald-50', border: 'border-emerald-200', dot: 'bg-emerald-500' },
  degraded: { label: 'Degraded', icon: AlertTriangle, color: 'text-amber-600', bg: 'bg-amber-50', border: 'border-amber-200', dot: 'bg-amber-500' },
  down: { label: 'Down', icon: XCircle, color: 'text-red-600', bg: 'bg-red-50', border: 'border-red-200', dot: 'bg-red-500' },
  maintenance: { label: 'Maintenance', icon: Wrench, color: 'text-blue-600', bg: 'bg-blue-50', border: 'border-blue-200', dot: 'bg-blue-500' },
};

export function SystemHealth({ navigate }: SystemHealthProps) {
  const { apiFailures } = useApp();
  const revenueFailure = apiFailures.find((f) => f.department === 'Revenue Department');
  const revenueIsDown = !!revenueFailure?.isDown && revenueFailure.retryState !== 'recovered';

  // Merge live failure state into health items
  const healthItems = systemHealthItems.map((item) => {
    if (item.name === 'Revenue Department API' && revenueIsDown) {
      return { ...item, status: 'down' as SystemHealthStatus, errorRate: 100, lastIncident: 'API DOWN — Automatic retry in progress' };
    }
    return item;
  });

  const operationalCount = healthItems.filter((s) => s.status === 'operational').length;
  const degradedCount = healthItems.filter((s) => s.status === 'degraded').length;
  const downCount = healthItems.filter((s) => s.status === 'down').length;
  const maintenanceCount = healthItems.filter((s) => s.status === 'maintenance').length;

  const latencyData = healthItems
    .filter((s) => s.status !== 'maintenance')
    .map((s) => ({ name: s.name.split(' ')[0], latency: s.latency, errorRate: s.errorRate }));

  return (
    <div className="mx-auto max-w-7xl px-4 py-6 sm:px-6 lg:px-8">
      <div className="mb-6 animate-fade-in-up">
        <h1 className="font-display text-2xl font-bold tracking-tight">System Health</h1>
        <p className="mt-1 text-sm text-muted-foreground">
          Real-time uptime, latency, and error rates for all department APIs and services.
        </p>
      </div>

      {/* Overall status banner */}
      <Card className={cn('mb-6 border-border/60 animate-fade-in-up', (downCount > 0 || degradedCount > 0) && 'border-amber-200')}>
        <CardContent className="flex items-center gap-4 p-5">
          <div className={cn('flex h-14 w-14 items-center justify-center rounded-xl', downCount > 0 ? 'bg-red-50' : degradedCount > 0 ? 'bg-amber-50' : 'bg-emerald-50')}>
            {downCount > 0 ? <XCircle className="h-7 w-7 text-red-600" /> : degradedCount > 0 ? <AlertTriangle className="h-7 w-7 text-amber-600" /> : <CheckCircle2 className="h-7 w-7 text-emerald-600" />}
          </div>
          <div>
            <h2 className="font-display text-lg font-bold">
              {downCount > 0 ? 'System Down — Active Failure' : degradedCount > 0 ? 'Some Systems Degraded' : 'All Systems Operational'}
            </h2>
            <p className="text-sm text-muted-foreground">
              {operationalCount} operational · {degradedCount} degraded · {downCount} down · {maintenanceCount} maintenance
            </p>
          </div>
        </CardContent>
      </Card>

      {/* Active failure alert */}
      {revenueIsDown && (
        <Card className="mb-6 border-red-200 bg-red-50/50 animate-fade-in-up">
          <CardContent className="p-4">
            <div className="flex items-start gap-3">
              <AlertTriangle className="mt-0.5 h-5 w-5 shrink-0 text-red-600" />
              <div>
                <p className="text-sm font-semibold text-red-900">Revenue API is DOWN</p>
                <p className="text-xs text-red-700 mt-1">{revenueFailure?.message}</p>
                <p className="text-xs text-blue-700 mt-1">{revenueFailure?.citizenMessage}</p>
                <p className="text-xs text-muted-foreground mt-1">Request ID: {revenueFailure?.requestId}</p>
              </div>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Latency chart */}
      <Card className="mb-6 border-border/60 animate-fade-in-up">
        <CardHeader>
          <CardTitle className="text-base">Latency & Error Rate by Service</CardTitle>
          <CardDescription>Average response time (ms) and error rate (%) across active services</CardDescription>
        </CardHeader>
        <CardContent>
          <ResponsiveContainer width="100%" height={300}>
            <BarChart data={latencyData}>
              <CartesianGrid strokeDasharray="3 3" stroke="hsl(210 40% 90%)" vertical={false} />
              <XAxis dataKey="name" tick={{ fontSize: 11 }} stroke="hsl(210 40% 50%)" angle={-20} textAnchor="end" height={60} />
              <YAxis yAxisId="left" tick={{ fontSize: 11 }} stroke="hsl(210 40% 50%)" unit="ms" />
              <YAxis yAxisId="right" orientation="right" tick={{ fontSize: 11 }} stroke="hsl(210 40% 50%)" unit="%" />
              <Tooltip contentStyle={{ borderRadius: '8px', fontSize: '12px' }} />
              <Bar yAxisId="left" dataKey="latency" fill="hsl(210 80% 50%)" radius={[4, 4, 0, 0]} name="Latency (ms)" />
              <Bar yAxisId="right" dataKey="errorRate" fill="hsl(0 72% 51%)" radius={[4, 4, 0, 0]} name="Error Rate (%)" />
            </BarChart>
          </ResponsiveContainer>
        </CardContent>
      </Card>

      {/* Service cards */}
      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3 animate-fade-in-up">
        {healthItems.map((item) => {
          const cfg = statusConfig[item.status];
          const StatusIcon = cfg.icon;
          return (
            <Card key={item.id} className={cn('border-border/60', item.status !== 'operational' && cfg.border)}>
              <CardContent className="p-5">
                <div className="flex items-start justify-between">
                  <div className="flex items-center gap-3">
                    <div className={cn('flex h-10 w-10 items-center justify-center rounded-lg', cfg.bg)}>
                      <HeartPulse className={cn('h-5 w-5', cfg.color)} />
                    </div>
                    <div>
                      <h3 className="font-display font-semibold">{item.name}</h3>
                      <p className="text-xs text-muted-foreground">{item.apiCount} API{item.apiCount > 1 ? 's' : ''}</p>
                    </div>
                  </div>
                  <div className="flex items-center gap-1.5">
                    <span className={cn('h-2 w-2 rounded-full', cfg.dot)} />
                    <Badge variant="outline" className={cn(cfg.bg, cfg.color)}>
                      {cfg.label}
                    </Badge>
                  </div>
                </div>

                <div className="mt-4 grid grid-cols-3 gap-2 text-center">
                  <div className="rounded-lg border bg-muted/30 p-2">
                    <p className="text-sm font-bold">{item.uptime > 0 ? `${item.uptime}%` : '—'}</p>
                    <p className="text-[10px] text-muted-foreground">Uptime</p>
                  </div>
                  <div className="rounded-lg border bg-muted/30 p-2">
                    <p className="text-sm font-bold">{item.latency > 0 ? `${item.latency}ms` : '—'}</p>
                    <p className="text-[10px] text-muted-foreground">Latency</p>
                  </div>
                  <div className="rounded-lg border bg-muted/30 p-2">
                    <p className={cn('text-sm font-bold', item.errorRate > 5 && 'text-red-600', item.errorRate > 1 && item.errorRate <= 5 && 'text-amber-600')}>
                      {item.errorRate < 100 ? `${item.errorRate}%` : '—'}
                    </p>
                    <p className="text-[10px] text-muted-foreground">Errors</p>
                  </div>
                </div>

                <div className="mt-3 flex items-center gap-2 text-xs text-muted-foreground">
                  <Activity className="h-3 w-3" />
                  {item.lastIncident}
                </div>
              </CardContent>
            </Card>
          );
        })}
      </div>

      <div className="mt-4 flex items-center justify-end">
        <Button variant="ghost" size="sm" onClick={() => navigate('/admin/dashboard')} className="gap-1">
          <ArrowRight className="h-3.5 w-3.5 rotate-180" />
          Back to Dashboard
        </Button>
      </div>
    </div>
  );
}
