import {
  FileText, Clock, AlertTriangle, CheckCircle2, ArrowRight,
  Building2, TrendingUp,
} from 'lucide-react';
import {
  PieChart, Pie, Cell, ResponsiveContainer, BarChart, Bar,
  XAxis, YAxis, CartesianGrid, Tooltip, Legend, LineChart, Line,
} from 'recharts';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { useApp } from '@/context/AppContext';
import { officerInfo, chartData } from '@/data/mockData';

interface OfficerDashboardProps {
  navigate: (to: string) => void;
}

const slaDaysByService: Record<string, number> = {
  'MahaScholarship': 20,
  'Income Certificate': 10,
  'Student Education Benefit': 15,
  'Social Welfare Scheme': 30,
  'Health Assistance Scheme': 7,
};
const defaultSlaDays = 15;

export function OfficerDashboard({ navigate }: OfficerDashboardProps) {
  const { applications } = useApp();

  const pendingApps = applications.filter(
    (a) => a.status === 'under_verification' || a.status === 'processing' || a.status === 'submitted'
  );

  const now = new Date('2026-08-25T00:00:00');
  let slaBreaches = 0;
  let dueToday = 0;
  for (const a of pendingApps) {
    const totalSlaDays = slaDaysByService[a.serviceName] ?? defaultSlaDays;
    const submitted = new Date(a.submittedAt);
    const deadline = new Date(submitted);
    deadline.setDate(deadline.getDate() + totalSlaDays);
    const daysRemaining = Math.ceil((deadline.getTime() - now.getTime()) / (1000 * 60 * 60 * 24));
    if (daysRemaining < 0) slaBreaches++;
    else if (daysRemaining <= 1) dueToday++;
  }
  const completedToday = applications.filter(
    (a) => a.status === 'approved' || a.status === 'rejected'
  ).length;

  const metrics = [
    { label: 'Pending Applications', value: pendingApps.length, icon: FileText, color: 'text-blue-600 bg-blue-50' },
    { label: 'Due Today', value: dueToday, icon: Clock, color: 'text-amber-600 bg-amber-50' },
    { label: 'SLA Breaches', value: slaBreaches, icon: AlertTriangle, color: 'text-red-600 bg-red-50' },
    { label: 'Completed Today', value: completedToday, icon: CheckCircle2, color: 'text-emerald-600 bg-emerald-50' },
  ];

  return (
    <div className="mx-auto max-w-7xl px-4 py-6 sm:px-6 lg:px-8">
      {/* Header */}
      <div className="mb-6 animate-fade-in-up">
        <h1 className="font-display text-2xl font-bold tracking-tight">
          Officer Dashboard
        </h1>
        <div className="mt-1 flex flex-wrap items-center gap-3 text-sm text-muted-foreground">
          <span className="font-medium">{officerInfo.name}</span>
          <span className="text-muted-foreground/40">·</span>
          <span>{officerInfo.designation}</span>
          <span className="text-muted-foreground/40">·</span>
          <span className="flex items-center gap-1">
            <Building2 className="h-3.5 w-3.5" />
            {officerInfo.department}
          </span>
        </div>
      </div>

      {/* Metrics */}
      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
        {metrics.map((m, i) => {
          const Icon = m.icon;
          return (
            <Card key={m.label} className="border-border/60 animate-fade-in-up" style={{ animationDelay: `${i * 0.05}s` }}>
              <CardContent className="p-5">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-xs font-medium text-muted-foreground">{m.label}</p>
                    <p className="mt-1 font-display text-3xl font-bold">{m.value}</p>
                  </div>
                  <div className={`flex h-11 w-11 items-center justify-center rounded-xl ${m.color}`}>
                    <Icon className="h-5 w-5" />
                  </div>
                </div>
              </CardContent>
            </Card>
          );
        })}
      </div>

      {/* Charts row */}
      <div className="mt-6 grid gap-6 lg:grid-cols-2">
        {/* Applications by Status */}
        <Card className="border-border/60 animate-fade-in-up">
          <CardHeader>
            <CardTitle className="text-base">Applications by Status</CardTitle>
            <CardDescription>Distribution of current applications across processing stages</CardDescription>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={240}>
              <PieChart>
                <Pie
                  data={chartData.applicationsByStatus}
                  dataKey="value"
                  nameKey="name"
                  cx="50%"
                  cy="50%"
                  outerRadius={80}
                  innerRadius={50}
                  paddingAngle={3}
                >
                  {chartData.applicationsByStatus.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={entry.fill} />
                  ))}
                </Pie>
                <Tooltip
                  contentStyle={{
                    borderRadius: '8px',
                    border: '1px solid hsl(var(--border))',
                    fontSize: '12px',
                  }}
                />
                <Legend
                  verticalAlign="bottom"
                  height={36}
                  iconType="circle"
                  wrapperStyle={{ fontSize: '11px' }}
                />
              </PieChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>

        {/* Processing Time */}
        <Card className="border-border/60 animate-fade-in-up delay-100">
          <CardHeader>
            <CardTitle className="text-base">Processing Time (days)</CardTitle>
            <CardDescription>Average processing time by service over the past week</CardDescription>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={240}>
              <BarChart data={chartData.processingTime} barGap={4}>
                <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" vertical={false} />
                <XAxis dataKey="day" tick={{ fontSize: 11 }} stroke="hsl(var(--muted-foreground))" />
                <YAxis tick={{ fontSize: 11 }} stroke="hsl(var(--muted-foreground))" />
                <Tooltip
                  contentStyle={{
                    borderRadius: '8px',
                    border: '1px solid hsl(var(--border))',
                    fontSize: '12px',
                  }}
                />
                <Legend wrapperStyle={{ fontSize: '11px' }} iconType="circle" />
                <Bar dataKey="mahaScholarship" fill="hsl(210 80% 50%)" radius={[3, 3, 0, 0]} />
                <Bar dataKey="incomeCert" fill="hsl(142 64% 42%)" radius={[3, 3, 0, 0]} />
                <Bar dataKey="eduBenefit" fill="hsl(38 92% 50%)" radius={[3, 3, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>

        {/* SLA Compliance */}
        <Card className="border-border/60 animate-fade-in-up delay-200">
          <CardHeader>
            <CardTitle className="text-base">SLA Compliance</CardTitle>
            <CardDescription>Weekly SLA compliance percentage trend</CardDescription>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={240}>
              <LineChart data={chartData.slaCompliance}>
                <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" vertical={false} />
                <XAxis dataKey="week" tick={{ fontSize: 11 }} stroke="hsl(var(--muted-foreground))" />
                <YAxis domain={[90, 100]} tick={{ fontSize: 11 }} stroke="hsl(var(--muted-foreground))" />
                <Tooltip
                  contentStyle={{
                    borderRadius: '8px',
                    border: '1px solid hsl(var(--border))',
                    fontSize: '12px',
                  }}
                />
                <Line
                  type="monotone"
                  dataKey="compliance"
                  stroke="hsl(var(--accent))"
                  strokeWidth={2.5}
                  dot={{ fill: 'hsl(var(--accent))', r: 4 }}
                  activeDot={{ r: 6 }}
                />
              </LineChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>

        {/* Department Workload */}
        <Card className="border-border/60 animate-fade-in-up delay-300">
          <CardHeader>
            <CardTitle className="text-base">Department Workload</CardTitle>
            <CardDescription>Active applications per department</CardDescription>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={240}>
              <BarChart data={chartData.departmentWorkload} layout="vertical">
                <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" horizontal={false} />
                <XAxis type="number" tick={{ fontSize: 11 }} stroke="hsl(var(--muted-foreground))" />
                <YAxis dataKey="department" type="category" tick={{ fontSize: 11 }} stroke="hsl(var(--muted-foreground))" width={70} />
                <Tooltip
                  contentStyle={{
                    borderRadius: '8px',
                    border: '1px solid hsl(var(--border))',
                    fontSize: '12px',
                  }}
                />
                <Bar dataKey="applications" radius={[0, 3, 3, 0]}>
                  {chartData.departmentWorkload.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={entry.color} />
                  ))}
                </Bar>
              </BarChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>
      </div>

      {/* Pending Applications Quick View */}
      <div className="mt-6">
        <div className="mb-3 flex items-center justify-between">
          <h2 className="font-display text-lg font-semibold">Pending Review</h2>
          <Button variant="ghost" size="sm" onClick={() => navigate('/officer/queue')} className="gap-1 text-muted-foreground">
            View Queue
            <ArrowRight className="h-4 w-4" />
          </Button>
        </div>
        <div className="space-y-3">
          {pendingApps.slice(0, 3).map((app, i) => (
            <Card
              key={app.id}
              className="cursor-pointer border-border/60 transition-all hover:shadow-md animate-fade-in-up"
              style={{ animationDelay: `${i * 0.05}s` }}
              onClick={() => navigate(`/officer/review/${app.id}`)}
            >
              <CardContent className="p-4">
                <div className="flex items-center justify-between">
                  <div>
                    <h3 className="font-display font-semibold">{app.serviceName}</h3>
                    <p className="mt-0.5 font-mono text-xs text-muted-foreground">{app.id}</p>
                  </div>
                  <div className="flex items-center gap-2">
                    <span className="text-xs text-muted-foreground">{app.progress}%</span>
                    <ArrowRight className="h-4 w-4 text-muted-foreground" />
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>

      {/* Impact summary */}
      <Card className="mt-6 border-accent/20 bg-accent/5 animate-fade-in-up">
        <CardContent className="p-5">
          <div className="flex items-center gap-2">
            <TrendingUp className="h-4 w-4 text-accent" />
            <h3 className="font-display text-sm font-semibold">Today's Summary</h3>
          </div>
          <p className="mt-2 text-xs text-muted-foreground">
            You have reviewed <span className="font-semibold text-foreground">{completedToday}</span> applications today,
            with <span className="font-semibold text-foreground">{dueToday}</span> due before end of day.
            <span className="font-semibold text-destructive">{slaBreaches}</span> applications have breached SLA and require immediate attention.
          </p>
          <Button variant="ghost" size="sm" className="mt-3 gap-1 px-0 text-accent hover:text-accent" onClick={() => navigate('/officer/sla')}>
            View SLA Report
            <ArrowRight className="h-3.5 w-3.5" />
          </Button>
        </CardContent>
      </Card>
    </div>
  );
}
